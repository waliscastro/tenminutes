<?php

namespace Elementor;

if (!defined('ABSPATH'))
    exit; // Exit if accessed directly

class Widget_profile extends Widget_Base {

    public function get_name() {
        return 'profile_short_base';
    }

    public function get_title() {
        return __('User Profile','adforest-elementor');
    }

    public function get_icon() {
        return 'fa fa-audio-description';
    }

    public function get_categories() {
        return ['adforest_elementor'];
    }

    protected function _register_controls() {
        
    }

    protected function render() {
        echo profile_short_base_func(array());
    }

}